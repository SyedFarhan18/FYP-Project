<?php
session_start();
include("connect.php"); // Make sure this file exists and is in the same folder

// Fetch all products to display (optional)
$query = "SELECT * FROM products";
$result = mysqli_query($conn, $query);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $price = $_POST["price"];
    $image = $_POST["image"];
    $description = $_POST["description"]; // Corrected

    $sql = "INSERT INTO products (name, price, image, description)
            VALUES ('$name','$price', '$image','$description')";

    if (mysqli_query($conn, $sql)) {
        echo "✅ Product added successfully.";
    } else {
        echo "❌ Error: " . mysqli_error($conn);
    }
}
?>

