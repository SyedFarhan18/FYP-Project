<?php
session_start();
include 'connect.php'; // ✅ Include the connection once

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if (empty($username) || empty($password)) {
        echo "<script>alert('Username and password cannot be empty.'); window.location.href = 'login.php';</script>";
        exit();
    }

    // Use prepared statement to fetch user
    $query = $conn->prepare("SELECT username, password FROM users WHERE username = ?");
    if (!$query) {
        die("Database error: " . $conn->error);
    }

    $query->bind_param("s", $username);
    $query->execute();
    $result = $query->get_result();
    $user = $result->fetch_assoc();
    $query->close();

    if (!$user) {
        echo "<script>alert('User not found. Please register first.'); window.location.href = 'register.php';</script>";
        exit();
    }

    if (password_verify($password, $user['password'])) {
        $_SESSION['username'] = $user['username'];
        session_regenerate_id(true);
        header("Location: index.html"); // ✅ Redirect to your homepage
        exit();
    } else {
        echo "<script>alert('Invalid username or password.'); window.location.href = 'login.php';</script>";
        exit();
    }
}


$conn->close();
?>
