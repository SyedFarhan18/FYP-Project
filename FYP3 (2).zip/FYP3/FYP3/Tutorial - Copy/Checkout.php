<?php
session_start();
include("connect.php");

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];

if (isset($_POST['buy_now'])) {
    // Buy a single product
    $product_id = $_POST['product_id'];
    $sql = "INSERT INTO orders (username, product_id, quantity, order_date) VALUES ('$username', '$product_id', 1, NOW())";
    mysqli_query($conn, $sql);
    echo "Thank you for your purchase!";
} elseif (isset($_POST['checkout'])) {
    // Checkout full cart
    $cart_query = "SELECT * FROM cart WHERE username='$username'";
    $cart_result = mysqli_query($conn, $cart_query);

    while ($row = mysqli_fetch_assoc($cart_result)) {
        $product_id = $row['product_id'];
        $qty = $row['quantity'];

        $order_query = "INSERT INTO orders (username, product_id, quantity, order_date) 
        VALUES ('$username', '$product_id', $qty, NOW())";
        mysqli_query($conn, $order_query);
    }

    // Clear cart
    mysqli_query($conn, "DELETE FROM cart WHERE username='$username'");
    echo "Order placed successfully!";
}
?>
