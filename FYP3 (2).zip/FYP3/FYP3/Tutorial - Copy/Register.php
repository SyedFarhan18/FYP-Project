<?php
session_start();
include 'connect.php'; // Database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Check if username and password are provided
    if (empty($username) || empty($password)) {
        die("<script>alert('Username and password cannot be empty.'); window.location.href = 'signup.php';</script>");
    }

    // Check if the user already exists
    $query = $conn->prepare("SELECT username FROM users WHERE username = ?");
    $query->bind_param("s", $username);
    $query->execute();
    $query->store_result();

    if ($query->num_rows > 0) {
        die("<script>alert('Username already exists. Try a different one.'); window.location.href = 'signup.php';</script>");
    }
    $query->close();

    // Hash the password securely
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert new user into the database
    $query = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    if (!$query) {
        die("Prepare failed: " . $conn->error);
    }

    $query->bind_param("ss", $username, $hashed_password);
    
    if ($query->execute()) {
        echo "<script>alert('Registration successful! You can now log in.'); window.location.href = 'login.php';</script>";
    } else {
        echo "<script>alert('Error registering user. Please try again.'); window.location.href = 'signup.php';</script>";
    }

    $query->close();
}
$conn->close();
?>


