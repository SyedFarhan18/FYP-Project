<?php
$host = "localhost";
$user = "root"; // Default XAMPP MySQL user
$password = "";
$database = "user_auth"; // Your database name

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>