<?php
session_start();
include("connect.php");

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$product_id = $_POST['product_id'];
$username = $_SESSION['username'];

// Check if item already in cart
$check = "SELECT * FROM cart WHERE username='$username' AND product_id='$product_id'";
$result = mysqli_query($conn, $check);

if (mysqli_num_rows($result) > 0) {
    // Update quantity
    $update = "UPDATE cart SET quantity = quantity + 1 WHERE username='$username' AND product_id='$product_id'";
    mysqli_query($conn, $update);
} else {
    // Insert new item
    $insert = "INSERT INTO cart (username, product_id, quantity) VALUES ('$username', '$product_id', 1)";
    mysqli_query($conn, $insert);
}

header("Location: cart.php");
exit();

