<?php
include("connect.php");

// Handle Delete
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM products WHERE id = $id");
    header("Location: manage_products.php");
}

// Handle Add
if (isset($_POST['add'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $image = $_POST['image'];
    $description = $_POST['description'];
    
    mysqli_query($conn, "INSERT INTO products (name, price, image, description) 
    VALUES ('$name', '$price', '$image', '$description')");
}

// Handle Update
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $image = $_POST['image'];
    $description = $_POST['description'];

    mysqli_query($conn, "UPDATE products SET name='$name', price='$price', image='$image', description='$description' WHERE id=$id");
}

// Fetch all products
$products = mysqli_query($conn, "SELECT * FROM products");
?>
